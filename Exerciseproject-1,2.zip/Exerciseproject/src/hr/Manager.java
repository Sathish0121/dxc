package hr;

public class Manager {
	
	public void managerSection() {
		System.out.println("This contains manager details");
	}

}
