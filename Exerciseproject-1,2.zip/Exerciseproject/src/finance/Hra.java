package finance;

public class Hra {
	
	public void hraDetails() {
		System.out.println("this section contains hra details");
	}

}
