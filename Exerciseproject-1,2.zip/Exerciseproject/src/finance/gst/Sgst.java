package finance.gst;

public class Sgst {
	
	public void sgstDetails() {
		System.out.println("this section contains sgst details");
	}

}
