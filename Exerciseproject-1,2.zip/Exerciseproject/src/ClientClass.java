import finance.*;
import finance.gst.*;
import hr.*;

public class ClientClass {

	public static void main(String[] args) {
		
		Employee e=new Employee();
		e.getEmployeeDetails();
		e.displayEmployeeDetails();
		Manager m=new Manager();
	   m.managerSection();
		
		Hra h=new Hra();
		h.hraDetails();
		Pf p=new Pf();
		p.pfDetails();
		Salary s=new Salary();
		s.SalaryDetails();
		Cgst cg=new Cgst();
		cg.cgstDetails();
		Sgst sg=new Sgst();
		sg.sgstDetails();
		// TODO Auto-generated method stub

	}

}
