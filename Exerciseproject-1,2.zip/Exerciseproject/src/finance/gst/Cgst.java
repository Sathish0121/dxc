package finance.gst;

public class Cgst {
	
	public void cgstDetails() {
		System.out.println("this section contains cgst details");
	}

}
