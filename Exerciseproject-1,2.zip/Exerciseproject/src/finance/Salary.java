package finance;

public class Salary {
	
	public void SalaryDetails() {
		System.out.println("This section contains salary details");
	}

}
