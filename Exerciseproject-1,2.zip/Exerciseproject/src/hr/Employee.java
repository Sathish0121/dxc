package hr;
import java.util.Scanner;

public class Employee {
	Scanner sc=new Scanner(System.in);
	String employeeName;
	long employeeID;
	String employeeDesignation;
	
	public void getEmployeeDetails() {
		System.out.println("enter employee details");
		System.out.println("employee name");
		employeeName=sc.next();
		System.out.println("employee ID");
		employeeID=sc.nextInt();
		System.out.println("employee designation");
		employeeDesignation=sc.next();
		
	}
	public void displayEmployeeDetails() {
		System.out.println(employeeName);
		System.out.println(employeeID);
		System.out.println(employeeDesignation);
	}

}
