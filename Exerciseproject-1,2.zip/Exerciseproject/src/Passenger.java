import java.util.Scanner;
public class Passenger {
	Scanner sc=new Scanner(System.in);
	
	String passengerName;
	long  pnrNumber;
	int rate;
	String journeyDate;
	String source;
	String destination;
	public void bookTicket() {
		System.out.println("Ticket booked for  :"+pnrNumber);
	}
	public void cancelTicket() {
		System.out.println("Ticket cancelled for :"+pnrNumber);
	}
	public void modifyTicket() {
		System.out.println("Enter passenger name :");
		passengerName=sc.next();
		System.out.println("Enter passenger pnrnumber :");
		pnrNumber=sc.nextInt();
		System.out.println("Enter passenger's Ticket price :");
		rate=sc.nextInt();
		System.out.println("Enter pssenger's  journey date:");
		journeyDate=sc.next();
		System.out.println("Enter passenger's source of journey :");
		source=sc.next();
		System.out.println("Enter passenger's destination of journey :");
		destination=sc.next();
		
	}
	public void displayTicketDetails() {
		System.out.println("passenger name  :"+passengerName);
		System.out.println("pnr number  :"+pnrNumber);
		System.out.println("ticket price "+rate);

		System.out.println("journey date  :"+journeyDate);
		System.out.println("source color  :"+source);

		System.out.println("source color  :"+destination);
	}

	public static void main(String[] args) {
		Passenger p=new Passenger();
		p.modifyTicket();
		p.bookTicket();
		p.cancelTicket();
		p.displayTicketDetails();
		// TODO Auto-generated method stub

	}

}